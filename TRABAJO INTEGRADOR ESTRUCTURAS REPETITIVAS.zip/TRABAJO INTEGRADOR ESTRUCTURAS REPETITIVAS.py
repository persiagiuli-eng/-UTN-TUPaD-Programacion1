#ACTIVIDAD 1 CAJA DEL KIOSCO
print('--- CAJA DEL KIOSCO ---')

nombre = ''

while nombre == '' or not nombre.isalpha():
    nombre = input('Nombre del cliente: ')

    if nombre == '' or not nombre.isalpha():
        print('Error: ingrese solamente letras.')

cantidad = ''

while cantidad == '' or not cantidad.isdigit() or int(cantidad) <= 0:
    cantidad = input('Cantidad de productos: ')

    if cantidad == '' or not cantidad.isdigit() or int(cantidad) <= 0:
        print('Error: ingrese un número entero mayor a 0.')

cantidad = int(cantidad)

total_sin_descuento = 0
total_con_descuento = 0

for i in range(cantidad):

    precio = ''

    while precio == '' or not precio.isdigit():
        precio = input('Producto ' + str(i + 1) + ' - Precio: ')

        if precio == '' or not precio.isdigit():
            print('Error: ingrese un precio válido.')

    precio = int(precio)

    descuento = ''

    while descuento.lower() != 's' and descuento.lower() != 'n':
        descuento = input('¿Tiene descuento? (S/N): ')

        if descuento.lower() != 's' and descuento.lower() != 'n':
            print('Error: ingrese S o N.')

    total_sin_descuento = total_sin_descuento + precio

    if descuento.lower() == 's':
        precio_final = precio * 0.90
    else:
        precio_final = precio

    total_con_descuento = total_con_descuento + precio_final


ahorro = total_sin_descuento - total_con_descuento
promedio = float(total_con_descuento) / cantidad

print()
print('--- RESULTADO ---')
print('Cliente:', nombre)
print('Cantidad de productos:', cantidad)
print('Total sin descuentos: $', total_sin_descuento)
print(f'Total con descuentos: ${total_con_descuento:.2f}')
print(f'Ahorro: ${ahorro:.2f}')
print(f'Promedio por producto: ${promedio:.2f}')

#Actividad 2 ACCESO AL CAMPUS

print('--- ACCESO AL CAMPUS ---')

usuario_correcto = 'alumno'
clave_correcta = 'python123'

intentos = 0
acceso = False

while intentos < 3 and acceso == False:

    print('Intento', intentos + 1, '/3')

    usuario = input('Usuario: ')
    clave = input('Clave: ')

    if usuario == usuario_correcto and clave == clave_correcta:
        acceso = True
        print('Acceso concedido.')
    else:
        print('Error: credenciales inválidas.')

    intentos = intentos + 1


if acceso == False:

    print('Cuenta bloqueada.')

else:

    opcion = ''

    while opcion != '4':

        print()
        print('--- MENÚ DEL CAMPUS ---')
        print('1) Ver estado de inscripción')
        print('2) Cambiar clave')
        print('3) Mostrar mensaje')
        print('4) Salir')

        opcion = input('Opción: ')

        while not opcion.isdigit() or int(opcion) < 1 or int(opcion) > 4:

            print('Error: opción inválida.')
            opcion = input('Opción: ')

        opcion = int(opcion)

        if opcion == 1:

            print('Estado de inscripción: Inscripto')

        elif opcion == 2:

            nueva_clave = input('Nueva clave: ')

            while len(nueva_clave) < 6:
                print('Error: mínimo 6 caracteres.')
                nueva_clave = input('Nueva clave: ')

            confirmacion = input('Confirmar nueva clave: ')

            if nueva_clave == confirmacion:
                clave_correcta = nueva_clave
                print('Clave cambiada correctamente.')
            else:
                print('Error: las claves no coinciden.')

        elif opcion == 3:

            print('¡Seguí estudiando, vas por buen camino!')

        elif opcion == 4:

            print('Sesión finalizada.')
            
#ACTIVIDAD 3

print('--- AGENDA DE TURNOS ---')

nombre_operador = ''

while nombre_operador == '' or not nombre_operador.isalpha():
    nombre_operador = input('Nombre del operador: ')

    if nombre_operador == '' or not nombre_operador.isalpha():
        print('Error: ingrese solamente letras.')


lunes1 = ''
lunes2 = ''
lunes3 = ''
lunes4 = ''

martes1 = ''
martes2 = ''
martes3 = ''


opcion = ''

while opcion != '5':

    print()
    print('--- MENÚ ---')
    print('1. Reservar turno')
    print('2. Cancelar turno')
    print('3. Ver agenda del día')
    print('4. Ver resumen general')
    print('5. Cerrar sistema')

    opcion = input('Opción: ')

    while not opcion.isdigit() or int(opcion) < 1 or int(opcion) > 5:
        print('Error: opción inválida.')
        opcion = input('Opción: ')

    opcion = int(opcion)


    # RESERVAR
    if opcion == 1:

        dia = input('Día: 1=Lunes / 2=Martes: ')

        while not dia.isdigit() or int(dia) < 1 or int(dia) > 2:
            print('Error: seleccione 1 o 2.')
            dia = input('Día: ')

        dia = int(dia)

        paciente = ''

        while paciente == '' or not paciente.isalpha():
            paciente = input('Nombre del paciente: ')

            if paciente == '' or not paciente.isalpha():
                print('Error: ingrese solamente letras.')


        if dia == 1:

            repetido = False

            if paciente == lunes1 or paciente == lunes2 or paciente == lunes3 or paciente == lunes4:
                repetido = True

            if repetido:
                print('Error: el paciente ya tiene un turno el lunes.')

            elif lunes1 == '':
                lunes1 = paciente
                print('Turno reservado correctamente.')

            elif lunes2 == '':
                lunes2 = paciente
                print('Turno reservado correctamente.')

            elif lunes3 == '':
                lunes3 = paciente
                print('Turno reservado correctamente.')

            elif lunes4 == '':
                lunes4 = paciente
                print('Turno reservado correctamente.')

            else:
                print('No hay turnos disponibles para el lunes.')


        elif dia == 2:

            repetido = False

            if paciente == martes1 or paciente == martes2 or paciente == martes3:
                repetido = True

            if repetido:
                print('Error: el paciente ya tiene un turno el martes.')

            elif martes1 == '':
                martes1 = paciente
                print('Turno reservado correctamente.')

            elif martes2 == '':
                martes2 = paciente
                print('Turno reservado correctamente.')

            elif martes3 == '':
                martes3 = paciente
                print('Turno reservado correctamente.')

            else:
                print('No hay turnos disponibles para el martes.')


    # CANCELAR
    elif opcion == 2:

        dia = input('Día: 1=Lunes / 2=Martes: ')

        while not dia.isdigit() or int(dia) < 1 or int(dia) > 2:
            print('Error: seleccione 1 o 2.')
            dia = input('Día: ')

        dia = int(dia)

        paciente = ''

        while paciente == '' or not paciente.isalpha():
            paciente = input('Nombre del paciente: ')

            if paciente == '' or not paciente.isalpha():
                print('Error: ingrese solamente letras.')


        encontrado = False

        if dia == 1:

            if paciente == lunes1:
                lunes1 = ''
                encontrado = True

            elif paciente == lunes2:
                lunes2 = ''
                encontrado = True

            elif paciente == lunes3:
                lunes3 = ''
                encontrado = True

            elif paciente == lunes4:
                lunes4 = ''
                encontrado = True

        elif dia == 2:

            if paciente == martes1:
                martes1 = ''
                encontrado = True

            elif paciente == martes2:
                martes2 = ''
                encontrado = True

            elif paciente == martes3:
                martes3 = ''
                encontrado = True


        if encontrado:
            print('Turno cancelado correctamente.')
        else:
            print('No se encontró el turno.')


    # VER AGENDA
    elif opcion == 3:

        dia = input('Día: 1=Lunes / 2=Martes: ')

        while not dia.isdigit() or int(dia) < 1 or int(dia) > 2:
            print('Error: seleccione 1 o 2.')
            dia = input('Día: ')

        dia = int(dia)

        if dia == 1:

            print('--- AGENDA LUNES ---')

            if lunes1 == '':
                print('Turno 1: (libre)')
            else:
                print('Turno 1:', lunes1)

            if lunes2 == '':
                print('Turno 2: (libre)')
            else:
                print('Turno 2:', lunes2)

            if lunes3 == '':
                print('Turno 3: (libre)')
            else:
                print('Turno 3:', lunes3)

            if lunes4 == '':
                print('Turno 4: (libre)')
            else:
                print('Turno 4:', lunes4)


        elif dia == 2:

            print('--- AGENDA MARTES ---')

            if martes1 == '':
                print('Turno 1: (libre)')
            else:
                print('Turno 1:', martes1)

            if martes2 == '':
                print('Turno 2: (libre)')
            else:
                print('Turno 2:', martes2)

            if martes3 == '':
                print('Turno 3: (libre)')
            else:
                print('Turno 3:', martes3)


    # RESUMEN
    elif opcion == 4:

        ocupados_lunes = 0

        if lunes1 != '':
            ocupados_lunes = ocupados_lunes + 1
        if lunes2 != '':
            ocupados_lunes = ocupados_lunes + 1
        if lunes3 != '':
            ocupados_lunes = ocupados_lunes + 1
        if lunes4 != '':
            ocupados_lunes = ocupados_lunes + 1


        ocupados_martes = 0

        if martes1 != '':
            ocupados_martes = ocupados_martes + 1
        if martes2 != '':
            ocupados_martes = ocupados_martes + 1
        if martes3 != '':
            ocupados_martes = ocupados_martes + 1


        print('--- RESUMEN GENERAL ---')
        print('Lunes: ', ocupados_lunes, 'ocupados y', 4 - ocupados_lunes, 'disponibles.')
        print('Martes:', ocupados_martes, 'ocupados y', 3 - ocupados_martes, 'disponibles.')


        if ocupados_lunes > ocupados_martes:
            print('El lunes tiene más turnos.')

        elif ocupados_martes > ocupados_lunes:
            print('El martes tiene más turnos.')

        else:
            print('Hay empate entre lunes y martes.')


print('Sistema cerrado.')

#ACTIVIDAD 4 ESCAPE ROOM:LA BOVEDA

print('--- ESCAPE ROOM: LA BÓVEDA ---')

nombre = ''

while nombre == '' or not nombre.isalpha():
    nombre = input('Nombre del agente: ')

    if nombre == '' or not nombre.isalpha():
        print('Error: ingrese solamente letras.')


energia = 100
tiempo = 12
cerraduras_abiertas = 0
alarma = False
codigo_parcial = ''

forzar_seguidas = 0


while energia > 0 and tiempo > 0 and cerraduras_abiertas < 3 and alarma == False:

    print()
    print('--- ESTADO ---')
    print('Agente:', nombre)
    print('Energía:', energia)
    print('Tiempo:', tiempo)
    print('Cerraduras abiertas:', cerraduras_abiertas)
    print('Código:', codigo_parcial)

    print()
    print('1. Forzar cerradura')
    print('2. Hackear panel')
    print('3. Descansar')

    opcion = input('Opción: ')

    while not opcion.isdigit() or int(opcion) < 1 or int(opcion) > 3:
        print('Error: ingrese una opción del 1 al 3.')
        opcion = input('Opción: ')

    opcion = int(opcion)


    # FORZAR CERRADURA
    if opcion == 1:

        energia = energia - 20
        tiempo = tiempo - 2

        forzar_seguidas = forzar_seguidas + 1

        if forzar_seguidas == 3:

            print('La cerradura se trabó.')
            print('¡ALARMA ACTIVADA!')

            alarma = True

        else:

            if energia < 40:

                riesgo = input('Riesgo de alarma. Elija 1, 2 o 3: ')

                while not riesgo.isdigit() or int(riesgo) < 1 or int(riesgo) > 3:
                    print('Error: ingrese un número del 1 al 3.')
                    riesgo = input('Riesgo de alarma. Elija 1, 2 o 3: ')

                riesgo = int(riesgo)

                if riesgo == 3:
                    alarma = True
                    print('¡ALARMA ACTIVADA!')

            if alarma == False:
                cerraduras_abiertas = cerraduras_abiertas + 1
                print('¡Cerradura abierta!')


    # HACKEAR PANEL
    elif opcion == 2:

        energia = energia - 10
        tiempo = tiempo - 3

        forzar_seguidas = 0

        print('--- HACKEANDO PANEL ---')

        for i in range(4):
            print('Paso', i + 1, 'completado.')
            codigo_parcial = codigo_parcial + 'A'

        print('Código actual:', codigo_parcial)

        if len(codigo_parcial) >= 8 and cerraduras_abiertas < 3:
            cerraduras_abiertas = cerraduras_abiertas + 1
            print('¡El panel abrió una cerradura!')


    # DESCANSAR
    elif opcion == 3:

        forzar_seguidas = 0

        tiempo = tiempo - 1

        energia = energia + 15

        if energia > 100:
            energia = 100

        if alarma == True:
            energia = energia - 10

        print('Descansaste.')
        print('Energía actual:', energia)


    # BLOQUEO POR ALARMA
    if alarma == True and tiempo <= 3 and cerraduras_abiertas < 3:
        print('La bóveda quedó bloqueada por la alarma.')
        break


print()

if cerraduras_abiertas == 3:
    print('¡VICTORIA!')
    print('Abriste las 3 cerraduras.')

elif alarma == True:
    print('DERROTA.')
    print('La bóveda quedó bloqueada.')

elif energia <= 0 or tiempo <= 0:
    print('DERROTA.')
    print('Te quedaste sin energía o sin tiempo.')
    
#ACTIVIDAD 5 ESCAPE ROOM:LA ARENA DEL GLADIADOR

print('--- BIENVENIDO A LA ARENA ---')

nombre = ''

while nombre == '' or not nombre.isalpha():
    nombre = input('Nombre del Gladiador: ')

    if nombre == '' or not nombre.isalpha():
        print('Error: Solo se permiten letras.')


vida_jugador = 100
vida_enemigo = 100
pociones = 3

ataque_jugador = 15
ataque_enemigo = 12

turno_gladiador = True


print()
print('=== INICIO DEL COMBATE ===')


while vida_jugador > 0 and vida_enemigo > 0:

    if turno_gladiador == True:

        print()
        print(nombre, '(HP:', vida_jugador, ')')
        print('Enemigo (HP:', vida_enemigo, ')')
        print('Pociones:', pociones)

        print()
        print('1. Ataque Pesado')
        print('2. Ráfaga Veloz')
        print('3. Curar')

        opcion = input('Opción: ')

        while not opcion.isdigit() or int(opcion) < 1 or int(opcion) > 3:
            print('Error: Ingrese un número válido.')
            opcion = input('Opción: ')

        opcion = int(opcion)


        # ATAQUE PESADO
        if opcion == 1:

            if vida_enemigo < 20:

                daño = float(ataque_jugador) * 1.5

                print('¡GOLPE CRÍTICO!')

            else:

                daño = float(ataque_jugador)

            vida_enemigo = vida_enemigo - daño

            print('¡Atacaste al enemigo por', daño, 'puntos de daño!')


        # RÁFAGA VELOZ
        elif opcion == 2:

            print('>> ¡Inicias una ráfaga de golpes!')

            for i in range(3):

                vida_enemigo = vida_enemigo - 5

                print('> Golpe conectado por 5 de daño')


        # CURAR
        elif opcion == 3:

            if pociones > 0:

                vida_jugador = vida_jugador + 30

                if vida_jugador > 100:
                    vida_jugador = 100

                pociones = pociones - 1

                print('¡Te curaste 30 puntos!')

            else:

                print('¡No quedan pociones!')


        turno_gladiador = False


    # TURNO DEL ENEMIGO
    if vida_enemigo > 0 and vida_jugador > 0 and turno_gladiador == False:

        vida_jugador = vida_jugador - ataque_enemigo

        print()
        print('¡El enemigo te atacó por 12 puntos de daño!')

        turno_gladiador = True


print()

if vida_jugador > 0:

    print('¡VICTORIA!', nombre, 'ha ganado la batalla.')

else:

    print('DERROTA. Has caído en combate.')

